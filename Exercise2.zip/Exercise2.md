```python
 pip install opencv-python
```

    Requirement already satisfied: opencv-python in c:\programdata\anaconda3\lib\site-packages (4.5.4.60)
    Requirement already satisfied: numpy>=1.14.5 in c:\programdata\anaconda3\lib\site-packages (from opencv-python) (1.16.5)
    Note: you may need to restart the kernel to use updated packages.
    


```python
import cv2
```


```python
img = cv2.imread("dog.jpg")
```


```python
cv2.imshow('image window', img)
cv2.waitKey(0)
cv2.destroyAllWindows()

```


```python
# Python program to explain cv2.imshow() method

# importing cv2
import cv2

# path
image=cv2.imread('dog.jpg')


# Reading an image in default mode
image = cv2.imread(path)

# Window name in which image is displayed
window_name = 'Image'

# Using cv2.imshow() method
# Displaying the image
image=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
cv2.imshow(window_name, image)

#waits for user to press any key
#(this is necessary to avoid Python kernel form crashing)
cv2.waitKey()

#closing all open windows
cv2.destroyAllWindows()
```


```python
import cv2
from matplotlib import pyplot as plt
  
# create figure
fig = plt.figure(figsize=(10, 7))
  
# setting values to rows and column variables
rows = 2
columns = 2
  
# reading images
Image1 = cv2.imread('dog.jpg')
Image2 = cv2.imread('dog.jpg')
Image3 = cv2.imread('dog.jpg')
Image4 = cv2.imread('dog.jpg')
  
# Adds a subplot at the 1st position
fig.add_subplot(rows, columns, 1)
  
# showing image
plt.imshow(Image1)
plt.axis('off')
plt.title("First")
  
# Adds a subplot at the 2nd position
fig.add_subplot(rows, columns, 2)
  
# showing image
plt.imshow(Image2)
plt.axis('off')
plt.title("Second")
  
# Adds a subplot at the 3rd position
fig.add_subplot(rows, columns, 3)
  
# showing image
plt.imshow(Image3)
plt.axis('off')
plt.title("Third")
  
# Adds a subplot at the 4th position
fig.add_subplot(rows, columns, 4)
  
# showing image
plt.imshow(Image4)
plt.axis('off')
plt.title("Fourth")
```




    Text(0.5, 1.0, 'Fourth')




![png](output_5_1.png)



```python
#translation


import numpy as np
import cv2 as cv
img = cv.imread('dog.jpg',0)
rows,cols = img.shape
M = np.float32([[1,0,100],[0,1,50]])
dst = cv.warpAffine(img,M,(cols,rows))
plt.subplot(121),plt.imshow(M),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
#cv.imshow('img',dst)
#cv.waitKey(0)
#cv.destroyAllWindows()

```


![png](output_6_0.png)



```python
#resizing

import cv2
from matplotlib import pyplot as plt

img=cv2.imread('dog.jpg',cv2.IMREAD_COLOR)

resized=cv2.resize(img,None,fx=1,fy=2,interpolation=cv2.INTER_CUBIC)
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(resized),plt.title('Output')
plt.show()
#cv2.imshow("original pic",img)
#cv2.imshow("resized pic",resized)
#cv2.waitKey()
#cv2.destroyAllWindows()
```


![png](output_7_0.png)



```python
#rotation

img = cv.imread('dog.jpg',0)
rows,cols = img.shape
# cols-1 and rows-1 are the coordinate limits.
M = cv.getRotationMatrix2D(((cols-1)/2.0,(rows-1)/2.0),90,1)
dst = cv.warpAffine(img,M,(cols,rows))
plt.subplot(121),plt.imshow(M),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
#cv.imshow('img',dst)
cv2.waitKey()
#cv2.destroyAllWindows()

```


![png](output_8_0.png)





    -1




```python
# Affine transformation

img = cv.imread('dog.jpg')
rows,cols,ch = img.shape
pts1 = np.float32([[50,50],[200,50],[50,200]])
pts2 = np.float32([[10,100],[200,50],[100,250]])
M = cv.getAffineTransform(pts1,pts2)
dst = cv.warpAffine(img,M,(cols,rows))
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
```


![png](output_9_0.png)



```python
# Perspective transformation

img = cv.imread('dog.jpg')
rows,cols,ch = img.shape
pts1 = np.float32([[56,65],[268,32],[28,287],[289,390]])
pts2 = np.float32([[0,0],[300,0],[0,300],[300,300]])
M = cv.getPerspectiveTransform(pts1,pts2)
dst = cv.warpPerspective(img,M,(200,200))
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
```




    (<matplotlib.axes._subplots.AxesSubplot at 0x23082266e08>,
     <matplotlib.image.AxesImage at 0x23083284408>,
     Text(0.5, 1.0, 'Output'))




![png](output_10_1.png)



```python

```


```python

```
